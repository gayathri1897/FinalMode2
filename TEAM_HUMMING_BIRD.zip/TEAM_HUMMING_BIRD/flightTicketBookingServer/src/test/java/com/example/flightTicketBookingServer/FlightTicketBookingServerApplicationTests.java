package com.example.flightTicketBookingServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightTicketBookingServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
