package com.company.Registration.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.Registration.dto.BookTicketRequestDto;
import com.company.Registration.dto.FlightResponseDto;
import com.company.Registration.dto.FlightSeatResponseDto;
import com.company.Registration.dto.MealResponseDto;
import com.company.Registration.dto.OrdersRequestDto;
import com.company.Registration.dto.TicketResponseDto;
import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.responseContract.ResponseContract;
import com.company.Registration.service.RegistrationService;

import ch.qos.logback.classic.Logger;

@RestController
public class RegistrationController {

	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(RegistrationController.class);

	@Autowired
	RegistrationService registrationService;
	@Autowired
	RestTemplate restTemplate;
	
	/*
	 * Registration of user
	 * 
	 * @Param UserRequestDto->class that takes user personal information to
	 * register.
	 * 
	 * @Return ResponseContract->returns user id with status code.
	 */

	@PostMapping("/users")
	public ResponseEntity<ResponseContract> registration(@RequestBody UserRequestDto userRequestDto) {
		LOGGER.info("Inside user registration");
		return registrationService.saveUser(userRequestDto);
	}

	/*
	 * Validation of user
	 * 
	 * @Param userId, password
	 * 
	 * @Return message
	 */
	@GetMapping("/users/login")
	public ResponseEntity<String> login(@RequestParam("userId") int userId, @RequestParam("password") String password,
			HttpSession session) {
		LOGGER.info("Inside user login");
		return registrationService.validate(userId, password);
		
	}
	
	/*
	 * Searching of Flights
	 * 
	 * @Path source,destination,date
	 * 
	 * @Return List of flights matching the data given
	 */
	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> searchFlights(@RequestParam("source") String source,
			@RequestParam("destination") String destination, @RequestParam("date") Date date) {
		LOGGER.info("Inside flight search");
		String searchFlightsUrl="http://flightSearch/flights?source="+source+"&destination="+destination+"&date="+date;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List<FlightResponseDto>> searchFlights = new HttpEntity<List<FlightResponseDto>>(headers);
		ResponseEntity<List<FlightResponseDto>>response=restTemplate.exchange(searchFlightsUrl, HttpMethod.GET,searchFlights,new ParameterizedTypeReference<List<FlightResponseDto>>(){}); 
		return new ResponseEntity<List<FlightResponseDto>>(response.getBody(),HttpStatus.OK);
	}
	
	/*
	 * Filtering flights by name
	 * 
	 * @Path name
	 * 
	 * @Return list of flights 
	 */ 
	@GetMapping("/flights/name")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByName(@RequestParam("name") String name) {
		LOGGER.info("Inside filter flights by name");
		String searchFlightsUrl="http://flightSearch/flights/name?name="+name;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List<FlightResponseDto>> searchFlights = new HttpEntity<List<FlightResponseDto>>(headers);
		ResponseEntity<List<FlightResponseDto>>response=restTemplate.exchange(searchFlightsUrl, HttpMethod.GET,searchFlights,new ParameterizedTypeReference<List<FlightResponseDto>>(){}); 
		return new ResponseEntity<List<FlightResponseDto>>(response.getBody(),HttpStatus.OK);
	}
	
	/*
	 * Filtering flights by cost
	 * 
	 * @Path cost
	 * 
	 * @Return list of flights
	 */
	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByCost(@RequestParam("cost") double cost) {
		LOGGER.info("Inside filter flights by cost");
		ResponseEntity<List<FlightResponseDto>>response;
		String searchFlightsUrl="http://flightSearch/flights/cost?cost="+cost;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List<FlightResponseDto>> searchFlights = new HttpEntity<List<FlightResponseDto>>(headers);
		response=restTemplate.exchange(searchFlightsUrl, HttpMethod.GET,searchFlights,new ParameterizedTypeReference<List<FlightResponseDto>>(){});
		return new ResponseEntity<List<FlightResponseDto>>(response.getBody(),HttpStatus.OK);
	}
	
	/*
	 * checking for availability of seats
	 * 
	 * @Path flightId
	 * 
	 * @Return FlightSeatResponseDto class that gives number of seats for the given flightId
	 */
	@GetMapping("/flights/{flightId}/seats")
	public ResponseEntity<FlightSeatResponseDto>checkAvailability(@PathVariable("flightId") int flightId) {
		LOGGER.info("Checking for availibility of seats for given flight");
		String availibilityUrl="http://flightSearch/flights/"+flightId+"/seats";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<FlightSeatResponseDto> searchFlights = new HttpEntity<FlightSeatResponseDto>(headers);
		ResponseEntity<FlightSeatResponseDto>response=restTemplate.exchange(availibilityUrl, HttpMethod.GET,searchFlights,FlightSeatResponseDto.class); 
		return new ResponseEntity<FlightSeatResponseDto>(response.getBody(),HttpStatus.OK);
		
	}
	
	/*
	 * Ticket Booking
	 * 
	 * @Param BookTicketRequestDto->takes the information that is useful for booking
	 * the ticket.
	 * 
	 * @Return ticketId with message
	 */
	@PostMapping("/ticket")
	public ResponseEntity<String> bookTicket(@RequestBody BookTicketRequestDto bookTicketRequestDto) {
		LOGGER.info("Inside ticket booking");
		String bookTicketUrl="http://flightTicket/ticket";
		ResponseEntity<String>ticketResponse=restTemplate.postForEntity(bookTicketUrl, bookTicketRequestDto, String.class);
		return new ResponseEntity<String>(ticketResponse.getBody(),HttpStatus.OK);
	}
	
	/*
	 * Ticket Details
	 * 
	 * @Path ticketId
	 * 
	 * @Returns Details about the booked ticket.
	 */
	@GetMapping("/tickets/{ticketId}")
	public ResponseEntity<TicketResponseDto> getTicket(@PathVariable("ticketId") int ticketId) {
		LOGGER.info("Getting ticket details");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String getTicketsUrl="http://flightTicket/tickets/"+ticketId;
		HttpEntity<TicketResponseDto> getTicketsEntity = new HttpEntity<TicketResponseDto>(headers);
		ResponseEntity<TicketResponseDto>ticketDetails=restTemplate.exchange(getTicketsUrl,HttpMethod.GET,getTicketsEntity,TicketResponseDto.class);
		return new ResponseEntity<TicketResponseDto>(ticketDetails.getBody(),HttpStatus.OK);
	}
	
	/*
	 * Canceling the ticket
	 * 
	 * @Path ticketId
	 * 
	 * @Return ticketId
	 */
	@DeleteMapping("/tickets/{ticketId}")
	public ResponseEntity<Integer>  cancelTicket(@PathVariable("ticketId")int ticketId) {
		LOGGER.info("Inside canceling ticket");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String cancelUrl="http://flightTicket/tickets/"+ticketId;
		HttpEntity<Integer> cancelEntity = new HttpEntity<Integer>(headers);
		restTemplate.exchange(cancelUrl,HttpMethod.DELETE,cancelEntity,Integer.class);
		return new ResponseEntity<Integer>(ticketId,HttpStatus.OK);
	}
	
	/*
	 * getting meals menu
	 * 
	 * @Path flightId
	 * 
	 * @Return List of meals corresponding to the flightID
	 */
	@GetMapping("/meals/{flightId}")
	public ResponseEntity<List<MealResponseDto>> getMeals(@PathVariable("flightId")int flightId){
		LOGGER.info("Inside getting meal menu");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String mealUrl="http://mealBox/meals/"+flightId;
		HttpEntity<List<MealResponseDto>> mealsMenu = new HttpEntity<List<MealResponseDto>>(headers);
		ResponseEntity<List<MealResponseDto>>response=restTemplate.exchange(mealUrl, HttpMethod.GET,mealsMenu,new ParameterizedTypeReference<List<MealResponseDto>>(){}); 
		return new ResponseEntity<List<MealResponseDto>>(response.getBody(),HttpStatus.OK);
	}
	
	/*
	 * order meals
	 * 
	 * @Path OrdersRequestDto
	 * 
	 * @Return String
	 */
	@PostMapping("/order/meals")
	public ResponseEntity<String> orderMeals(@RequestBody OrdersRequestDto ordersRequestDto){
		LOGGER.info("Inside order meals");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String mealOrderUrl="http://mealBox/order/meals";
		ResponseEntity<String>response=restTemplate.postForEntity(mealOrderUrl, ordersRequestDto, String.class);
		return new ResponseEntity<String>(response.getBody(),HttpStatus.OK);
		
	}
	
	/*
	 * canceling meals using ticketId
	 * 
	 * @Path ticketId
	 * 
	 * @Return String
	 */
	@DeleteMapping("/order/meals/{ticketId}")
	public ResponseEntity<String> cancelOrderedMeals(@PathVariable("ticketId")int ticketId){
		LOGGER.info("Inside cancel meals");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String mealCancelUrl="http://mealBox/order/meals/"+ticketId;
		HttpEntity<String> mealsMenu = new HttpEntity<String>(headers);
		ResponseEntity<String>response=restTemplate.exchange(mealCancelUrl,HttpMethod.DELETE,mealsMenu,String.class);
		return new ResponseEntity<String>(response.getBody(),HttpStatus.OK);
	}

}
