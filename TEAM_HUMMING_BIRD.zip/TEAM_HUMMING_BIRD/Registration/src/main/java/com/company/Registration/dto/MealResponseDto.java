package com.company.Registration.dto;

import org.springframework.stereotype.Component;

@Component
public class MealResponseDto {

	private Integer mealId;
	private String mealName;
	private double cost;
	public Integer getMealId() {
		return mealId;
	}
	public void setMealId(Integer mealId) {
		this.mealId = mealId;
	}
	public String getMealName() {
		return mealName;
	}
	public void setMealName(String mealName) {
		this.mealName = mealName;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
}
