package com.company.Registration.dto;

import org.springframework.stereotype.Component;

@Component
public class OrderDetailsDto {

private int mealId;
private int numberOfOrders;
public int getMealId() {
	return mealId;
}
public void setMealId(int mealId) {
	this.mealId = mealId;
}
public int getNumberOfOrders() {
	return numberOfOrders;
}
public void setNumberOfOrders(int numberOfOrders) {
	this.numberOfOrders = numberOfOrders;
}

}
