package com.company.Registration.service;

import org.springframework.http.ResponseEntity;

import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.responseContract.ResponseContract;

public interface RegistrationService {

	ResponseEntity<ResponseContract> saveUser(UserRequestDto userRequestDto);

	ResponseEntity<String> validate(int userId, String password);

	
}
