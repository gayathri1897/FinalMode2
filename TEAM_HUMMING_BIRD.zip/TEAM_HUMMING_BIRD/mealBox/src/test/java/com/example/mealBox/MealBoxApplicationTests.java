package com.example.mealBox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealBoxApplicationTests {

	@Test
	void contextLoads() {
	}

}
