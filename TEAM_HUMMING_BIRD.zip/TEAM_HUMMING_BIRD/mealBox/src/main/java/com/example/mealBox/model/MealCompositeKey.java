package com.example.mealBox.model;

import java.io.Serializable;


public class MealCompositeKey implements Serializable {

	private Integer mealId;
	private Integer orderId;
	public MealCompositeKey() {
		
	}
	public MealCompositeKey(Integer mealId, Integer orderId) {
		this.mealId=mealId;
		this.orderId=orderId;
	}
	public Integer getMealId() {
		return mealId;
	}
	public void setMealId(Integer mealId) {
		this.mealId = mealId;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	
	
}
