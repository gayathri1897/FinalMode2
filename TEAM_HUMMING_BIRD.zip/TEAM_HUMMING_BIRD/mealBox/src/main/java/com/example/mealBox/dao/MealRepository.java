package com.example.mealBox.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.mealBox.model.Meal;

@Repository
public interface MealRepository extends CrudRepository<Meal, Integer> {

	public List<Meal> findByFlightId(int flightId);

	public Meal findByMealId(int mealId);

}
