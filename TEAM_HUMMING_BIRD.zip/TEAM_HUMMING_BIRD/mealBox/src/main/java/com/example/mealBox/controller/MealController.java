package com.example.mealBox.controller;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.example.mealBox.dto.MealResponseDto;
import com.example.mealBox.service.MealService;

import ch.qos.logback.classic.Logger;

@RestController
public class MealController {
	@Autowired
	MealService mealService;
	
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(MealController.class);
	
	/*
	 * Getting meals menu for the given flightId
	 * 
	 * @Path flightId
	 * 
	 * @Return List of meals
	 */
	@GetMapping("/meals/{flightId}")
	public ResponseEntity<List<MealResponseDto>> getMeals(@PathVariable("flightId")int flightId){
		LOGGER.info("inside meals menu");
		return mealService.getMeals(flightId);
	}

}
