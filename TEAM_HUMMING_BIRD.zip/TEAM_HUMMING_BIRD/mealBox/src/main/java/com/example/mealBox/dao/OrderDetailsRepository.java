package com.example.mealBox.dao;

import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.mealBox.model.MealCompositeKey;
import com.example.mealBox.model.OrderDetails;

@Repository
public interface OrderDetailsRepository extends CrudRepository<OrderDetails, MealCompositeKey>{
	@Transactional
	@Modifying(clearAutomatically=true)
	@Query(value="delete from order_details where order_id=:order_id",nativeQuery=true)
	public void deleteByOrderId(@PathParam("order_id")int order_id);

}
