package com.example.mealBox.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.mealBox.dao.MealRepository;
import com.example.mealBox.dto.MealResponseDto;
import com.example.mealBox.exceptionHandling.FlightNotFoundException;
import com.example.mealBox.model.Meal;

@Service
public class MealServiceImpl implements MealService {
	@Autowired
	MealRepository mealRepository;

	@Autowired
	ModelMapper modelMapper;

	ArrayList<MealResponseDto> listOfMeals = new ArrayList<MealResponseDto>();

	/* This method gives the list of meals for the given flightId */
	@Override
	public ResponseEntity<List<MealResponseDto>> getMeals(int flightId) {
		listOfMeals.clear();
		List<Meal> meals = mealRepository.findByFlightId(flightId);
		if (meals.isEmpty()) {
			throw new FlightNotFoundException("flight not found");
		}
		meals.forEach(meal -> getMealList(meal));
		return new ResponseEntity<List<MealResponseDto>>(listOfMeals, HttpStatus.OK);
	}

	private void getMealList(Meal meal) {
		MealResponseDto mealResponseDto = modelMapper.map(meal, MealResponseDto.class);
		listOfMeals.add(mealResponseDto);
	}

}
