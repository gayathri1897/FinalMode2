package com.example.mealBox.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.mealBox.dto.MealResponseDto;

public interface MealService {

	public ResponseEntity<List<MealResponseDto>> getMeals(int flightId);

}
