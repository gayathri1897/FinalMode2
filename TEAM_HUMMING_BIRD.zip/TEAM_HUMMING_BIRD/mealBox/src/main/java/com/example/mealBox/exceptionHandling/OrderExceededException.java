package com.example.mealBox.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class OrderExceededException extends RuntimeException {
	public OrderExceededException(String exception) {
        super(exception);
    }

}
