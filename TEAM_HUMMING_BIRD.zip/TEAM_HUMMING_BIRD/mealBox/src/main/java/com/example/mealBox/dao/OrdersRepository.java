package com.example.mealBox.dao;

import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.mealBox.model.MealCompositeKey;
import com.example.mealBox.model.Orders;

@Repository
public interface OrdersRepository extends CrudRepository<Orders, Integer>{

	Optional<Orders> findByTicketId(int ticketId);


	

}
