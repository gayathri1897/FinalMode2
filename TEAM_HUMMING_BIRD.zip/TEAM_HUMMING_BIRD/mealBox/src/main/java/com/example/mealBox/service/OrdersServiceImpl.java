package com.example.mealBox.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.mealBox.dao.MealRepository;
import com.example.mealBox.dao.OrderDetailsRepository;
import com.example.mealBox.dao.OrdersRepository;
import com.example.mealBox.dto.OrderDetailsDto;
import com.example.mealBox.dto.OrdersRequestDto;
import com.example.mealBox.dto.TicketResponseDto;
import com.example.mealBox.exceptionHandling.OrderExceededException;
import com.example.mealBox.exceptionHandling.OrderNotFoundException;
import com.example.mealBox.exceptionHandling.TicketNotFoundException;
import com.example.mealBox.model.Meal;
import com.example.mealBox.model.MealCompositeKey;
import com.example.mealBox.model.OrderDetails;
import com.example.mealBox.model.Orders;

@Service
public class OrdersServiceImpl implements OrdersService{
	@Autowired
	OrdersRepository ordersRepository;
	@Autowired
	OrderDetailsRepository orderDetailsRepository;
	@Autowired 
	MealRepository mealRepository;
	@Autowired
	RestTemplate restTemplate;
	
static int orderId=700;

	/* Booking meals for the valid passengers */
	@Override
	public ResponseEntity<String> orderMeals(OrdersRequestDto ordersRequestDto) {
		int id=orderId++;
		Orders orders=new Orders();
		OrderDetails orderDetails=new OrderDetails();
		MealCompositeKey mealCompositeKey=new MealCompositeKey();
		
		
		List<OrderDetailsDto> orderDetailsDto=ordersRequestDto.getOrderDetails();
		int size=orderDetailsDto.size();
		double totalCost=0;
		int numberOfOrders=0;

		ResponseEntity<TicketResponseDto>ticketId;
		for(int i=0;i<size;i++) {
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.APPLICATION_JSON);
				String getTicketsUrl="http://flightTicket/tickets/"+ordersRequestDto.getTicketId();
				HttpEntity<TicketResponseDto> getTicketsEntity = new HttpEntity<TicketResponseDto>(headers);
				ticketId=restTemplate.exchange(getTicketsUrl,HttpMethod.GET,getTicketsEntity,TicketResponseDto.class);
			}catch(Exception e) {
				throw new TicketNotFoundException("Ticket Not Found");
			}
			Meal meal=mealRepository.findByMealId(orderDetailsDto.get(i).getMealId());
			totalCost+=orderDetailsDto.get(i).getNumberOfOrders()*meal.getCost();
			numberOfOrders+=orderDetailsDto.get(i).getNumberOfOrders();
			if(numberOfOrders>ticketId.getBody().getNumberOfTickets()) {
				throw new OrderExceededException("you can't order more than "+ticketId.getBody().getNumberOfTickets()+" meals");
			}
			mealCompositeKey.setMealId(orderDetailsDto.get(i).getMealId());
			mealCompositeKey.setOrderId(id);
			orderDetails.setMealCompositeKey(mealCompositeKey);
			orderDetails.setMealName(meal.getMealName());
			orderDetails.setNumberOfOrders(orderDetailsDto.get(i).getNumberOfOrders());
			orderDetails.setCost(meal.getCost());
			orderDetailsRepository.save(orderDetails);
		}
		orders.setOrderId(id);
		orders.setTicketId(ordersRequestDto.getTicketId());
		orders.setNumberOfOrders(numberOfOrders);
		orders.setCost(totalCost);
		ordersRepository.save(orders);
		return new ResponseEntity<String>("your order id is "+id, HttpStatus.OK);
	}
	
	/* canceling meals using ticketId */
	@Override
	public ResponseEntity<String> cancelOrderMeals(int ticketId) {
		Optional<Orders>optionalOrder=ordersRepository.findByTicketId(ticketId);
		if(!optionalOrder.isPresent()) {
			throw new OrderNotFoundException("order not found");
		}
		orderDetailsRepository.deleteByOrderId(optionalOrder.get().getOrderId());
		ordersRepository.deleteById(optionalOrder.get().getOrderId());
		
		return new ResponseEntity<String>("your order id "+optionalOrder.get().getOrderId()+" is successfully canceled", HttpStatus.OK);
	}

	
}
