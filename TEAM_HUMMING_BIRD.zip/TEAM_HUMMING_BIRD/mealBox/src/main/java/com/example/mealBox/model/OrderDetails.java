package com.example.mealBox.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class OrderDetails {
@EmbeddedId
	private MealCompositeKey mealCompositeKey;
	private String mealName;
	private int numberOfOrders;
	private double cost;
	
	public int getNumberOfOrders() {
		return numberOfOrders;
	}
	public void setNumberOfOrders(int numberOfOrders) {
		this.numberOfOrders = numberOfOrders;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public MealCompositeKey getMealCompositeKey() {
		return mealCompositeKey;
	}
	public void setMealCompositeKey(MealCompositeKey mealCompositeKey) {
		this.mealCompositeKey = mealCompositeKey;
	}
	public String getMealName() {
		return mealName;
	}
	public void setMealName(String mealName) {
		this.mealName = mealName;
	}
	
	
}
