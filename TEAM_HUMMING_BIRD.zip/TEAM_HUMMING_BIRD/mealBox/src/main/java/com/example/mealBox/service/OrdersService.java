package com.example.mealBox.service;

import org.springframework.http.ResponseEntity;

import com.example.mealBox.dto.OrdersRequestDto;

public interface OrdersService {

	public ResponseEntity<String> orderMeals(OrdersRequestDto ordersRequestDto);

	public ResponseEntity<String> cancelOrderMeals(int ticketId);

}
