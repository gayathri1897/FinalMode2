package com.example.mealBox.dto;

import java.util.List;

import org.springframework.stereotype.Component;


@Component
public class OrdersRequestDto {

	private int ticketId;
	private List<OrderDetailsDto> orderDetails;
	
	
	public List<OrderDetailsDto> getOrderDetails() {
		return orderDetails;
	}
	public void setOrderDetails(List<OrderDetailsDto> orderDetails) {
		this.orderDetails = orderDetails;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	
}
