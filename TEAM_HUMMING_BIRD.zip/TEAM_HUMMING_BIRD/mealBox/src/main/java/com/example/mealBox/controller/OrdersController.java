package com.example.mealBox.controller;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.mealBox.dto.OrdersRequestDto;
import com.example.mealBox.service.OrdersService;

import ch.qos.logback.classic.Logger;

@RestController
public class OrdersController {
	@Autowired
	OrdersService orderService;
	
	/*
	 * Order Meals
	 * 
	 * @Path OrderRequestDto
	 * 
	 * @Return String
	 */
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(OrdersController.class);
	@PostMapping("/order/meals")
	public ResponseEntity<String> orderMeals(@RequestBody OrdersRequestDto ordersRequestDto){
		LOGGER.info("inside order meals");
		return orderService.orderMeals(ordersRequestDto);
	}
	
	/*
	 * Canceling meals
	 * 
	 * @Path ticketId
	 * 
	 * @Return String
	 */
	@DeleteMapping("/order/meals/{ticketId}")
	public ResponseEntity<String> cancelOrderedMeals(@PathVariable("ticketId")int ticketId){
		LOGGER.info("inside cancel meals");
		return orderService.cancelOrderMeals(ticketId);
	}

}
