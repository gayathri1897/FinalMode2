package com.example.flightTicket.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.flightTicket.model.Ticket;

@Repository
public interface TicketRepository extends CrudRepository<Ticket,Integer>{

	Optional<Ticket> findByTicketId(int ticketId);

}
