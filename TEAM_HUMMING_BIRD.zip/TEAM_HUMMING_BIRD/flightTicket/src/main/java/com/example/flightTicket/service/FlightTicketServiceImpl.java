package com.example.flightTicket.service;


import java.sql.Date;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.flightTicket.controller.FlightTicketController;
import com.example.flightTicket.dao.PassengerRepository;
import com.example.flightTicket.dao.TicketRepository;
import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.FlightResponseDto;
import com.example.flightTicket.dto.FlightSeatResponseDto;
import com.example.flightTicket.dto.PassengerDetails;
import com.example.flightTicket.dto.TicketResponseDto;
import com.example.flightTicket.exceptionHandling.CategoryNotFoundException;
import com.example.flightTicket.exceptionHandling.FlightNotFoundException;
import com.example.flightTicket.exceptionHandling.SeatNotAvailableException;
import com.example.flightTicket.exceptionHandling.PassengerDetailsMismatchException;
import com.example.flightTicket.exceptionHandling.TicketNotFoundException;
import com.example.flightTicket.model.CompositeId;
import com.example.flightTicket.model.Passenger;
import com.example.flightTicket.model.Ticket;

import ch.qos.logback.classic.Logger;

@Service
public class FlightTicketServiceImpl implements FlightTicketService {
	static int pId = 4000;
	static int tId = 5000;
	
	@Autowired
    private JavaMailSender javaMailSender;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	ModelMapper modelMapper;

	@Autowired
	PassengerRepository passengerRepository;

	@Autowired
	TicketRepository ticketRepository;
	
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(FlightTicketServiceImpl.class);

	/* Book ticket after appropriate validations */
	@Override
	public ResponseEntity<String> bookTicket(BookTicketRequestDto bookTicketRequestDto) {

		/*getting all flight details for the given flightId*/
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		String flightUrl="http://flightSearch/flights/"+bookTicketRequestDto.getFlightId();
		HttpEntity<FlightResponseDto> flightEntity = new HttpEntity<FlightResponseDto>(headers);
		ResponseEntity<FlightResponseDto>flightResponse=restTemplate.exchange(flightUrl,HttpMethod.GET,flightEntity, FlightResponseDto.class);
		
		long millis=System.currentTimeMillis();  
	    Date date=new Date(millis); 
		if(date.compareTo(bookTicketRequestDto.getDate())>0) {
			throw new FlightNotFoundException("no flights");
		}
		
		/*
		 * Checking for availibility of seats and booking tickets only if seats are
		 * available.
		 */
		Boolean bool = false;
		String seatsUrl = "http://flightSearch/flights/{flightId}/seats";
		HttpEntity<FlightSeatResponseDto> seatEntity = new HttpEntity<FlightSeatResponseDto>(headers);
		UriComponentsBuilder seatbuilder = UriComponentsBuilder.fromUriString(seatsUrl);
		ResponseEntity<FlightSeatResponseDto> seatResponse;
		seatResponse = restTemplate.exchange(seatbuilder.buildAndExpand(bookTicketRequestDto.getFlightId()).toUri(),
				HttpMethod.GET, seatEntity, FlightSeatResponseDto.class);

		switch (bookTicketRequestDto.getCategory()) {
		case "business":
			if (seatResponse.getBody().getBusinessSeats() - bookTicketRequestDto.getNumberOfTickets() >= 0)
				bool = true;
			break;
		case "economy":
			if (seatResponse.getBody().getEconomySeats() - bookTicketRequestDto.getNumberOfTickets() >= 0)
				bool = true;
			break;
		default:
			throw new CategoryNotFoundException("Give proper category");
		}
		
		if (bool == false) {
			throw new SeatNotAvailableException("No seats available");
		}
		
		 if (bookTicketRequestDto.getPassenger().size() !=bookTicketRequestDto.getNumberOfTickets()) { 
			 throw new PassengerDetailsMismatchException("Enter all passenger details"); 
		}
		

		/* Getting airport name to print in ticket */
		String airportUrl = "http://flightSearch/airport?location=" + flightResponse.getBody().getSource();
		HttpEntity<String> airportEntity = new HttpEntity<String>(headers);
		ResponseEntity<String> airportResponse = restTemplate.exchange(airportUrl, HttpMethod.GET, airportEntity,
				String.class);

		/* Setting ticket details. */
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Ticket ticket = modelMapper.map(bookTicketRequestDto, Ticket.class);
		int ticketId = tId++;
		ticket.setTicketId(ticketId);
		ticket.setDestination(flightResponse.getBody().getDestination());
		ticket.setSource(flightResponse.getBody().getSource());
		ticket.setAirportName(airportResponse.getBody());
		ticket.setArrivalTime(flightResponse.getBody().getArrivalTime());
		ticket.setDepartureTime(flightResponse.getBody().getDepartureTime());
		
		switch (bookTicketRequestDto.getCategory()) {
		case "business":
			ticket.setCost(bookTicketRequestDto.getNumberOfTickets() * flightResponse.getBody().getBusinessCost());
			break;
		case "economy":
			ticket.setCost(bookTicketRequestDto.getNumberOfTickets() * flightResponse.getBody().getEconomyCost());
			break;
		}
		ticketRepository.save(ticket);

		/* calling the method to set passenger details */
		List<PassengerDetails> passengerList = bookTicketRequestDto.getPassenger();
		passengerList.stream().forEach(passenger -> setPassenger(passenger,ticketId));

		/* Updating seat in database after ticket booking */
		String updateSeatUrl = "http://flightSearch/flights/seats?flightId=" + bookTicketRequestDto.getFlightId()
				+ "&category=" + bookTicketRequestDto.getCategory() + "&numberOfTickets="
				+ bookTicketRequestDto.getNumberOfTickets();
		HttpEntity<Integer> updateSeatEntity = new HttpEntity<Integer>(headers);
		restTemplate.exchange(updateSeatUrl, HttpMethod.GET, updateSeatEntity, Integer.class);
		sendEmail(ticketId, bookTicketRequestDto.getMailId());
		return new ResponseEntity<String>("Ticket successfully booked.Your ticketId is "+ticket.getTicketId(), HttpStatus.OK);

	}

	/*setting passenger details*/
	public void setPassenger(PassengerDetails passengerDetail,int ticketId) {
		CompositeId compositeId = new CompositeId();
		compositeId.setTicketId(ticketId);
		compositeId.setPassengerId(pId++);
		Passenger passenger = new Passenger();
		passenger.setAge(passengerDetail.getAge());
		passenger.setName(passengerDetail.getName());
		passenger.setCompositeId(compositeId);
		passengerRepository.save(passenger);
	}

	/* Getting ticket details by passing ticket id */
	@Override
	public ResponseEntity<TicketResponseDto> getTicket(int ticketId) {

		Optional<Ticket> optionalTicket = ticketRepository.findByTicketId(ticketId);
		if (!optionalTicket.isPresent())
			throw new TicketNotFoundException("Improper ticket Id");
		Ticket ticket = optionalTicket.get();
		TicketResponseDto ticketResponseDto = modelMapper.map(ticket, TicketResponseDto.class);
		return new ResponseEntity<TicketResponseDto>(ticketResponseDto, HttpStatus.OK);

	}

	/* Canceling ticket using ticketId */
	@Override
	public ResponseEntity<Integer> cancelTicket(int ticketId) {
		Optional<Ticket> optionalTicket = ticketRepository.findById(ticketId);
		
		if (!optionalTicket.isPresent())
			throw new TicketNotFoundException("Improper ticket Id");
		Ticket ticket = optionalTicket.get();
		
		 long millis=System.currentTimeMillis();  
	        Date date=new Date(millis); 
		
		if(date.compareTo(ticket.getDate())>0) {
			throw new FlightNotFoundException("no flights");
		}
				
		String updateSeatUrl = "http://flightSearch/flights/cancel?flightId=" + ticket.getFlightId() + "&category="
				+ ticket.getCategory() + "&numberOfTickets=" + ticket.getNumberOfTickets();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Integer> updateSeatEntity = new HttpEntity<Integer>(headers);
		restTemplate.exchange(updateSeatUrl, HttpMethod.GET, updateSeatEntity, Integer.class);
		passengerRepository.deletePassengersById(ticketId);
		ticketRepository.deleteById(ticketId);
		
		String cancelMealUrl="http://mealBox/order/meals/"+ticketId;
		HttpEntity<String> cancelMealEntity = new HttpEntity<String>(headers);
		try {
		restTemplate.exchange(cancelMealUrl, HttpMethod.DELETE, cancelMealEntity, String.class);
		}catch(Exception e) {
			LOGGER.info("inside exception");
		}
		return new ResponseEntity<Integer>(ticketId, HttpStatus.OK);

	}
	void sendEmail(int ticketId,String mailId) {

        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(mailId);
        msg.setSubject("Testing from Spring Boot");
        msg.setText("Successfully booked the ticket, your ticket id is "+ticketId);

        javaMailSender.send(msg);

    }

}
