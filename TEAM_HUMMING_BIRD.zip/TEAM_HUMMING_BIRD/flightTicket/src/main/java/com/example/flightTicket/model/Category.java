package com.example.flightTicket.model;


public class Category {

private Integer flightId;	
private int businessSeats;	
private double businessCost;	
private int economySeats;	
private double economyCost;
public Integer getFlightId() {
	return flightId;
}
public void setFlightId(Integer flightId) {
	this.flightId = flightId;
}
public int getBusinessSeats() {
	return businessSeats;
}
public void setBusinessSeats(int businessSeats) {
	this.businessSeats = businessSeats;
}
public double getBusinessCost() {
	return businessCost;
}
public void setBusinessCost(double businessCost) {
	this.businessCost = businessCost;
}
public int getEconomySeats() {
	return economySeats;
}
public void setEconomySeats(int economySeats) {
	this.economySeats = economySeats;
}
public double getEconomyCost() {
	return economyCost;
}
public void setEconomyCost(double economyCost) {
	this.economyCost = economyCost;
}

}
