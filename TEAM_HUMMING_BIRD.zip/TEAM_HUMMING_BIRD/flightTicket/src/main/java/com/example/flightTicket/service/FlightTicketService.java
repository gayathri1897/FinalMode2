package com.example.flightTicket.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.TicketResponseDto;
import com.example.flightTicket.responseContract.ResponseContract;

public interface FlightTicketService {

	ResponseEntity<String> bookTicket(BookTicketRequestDto bookTicketRequestDto);

	ResponseEntity<TicketResponseDto>getTicket(int ticketId);

	ResponseEntity<Integer>  cancelTicket(int ticketId);

}
