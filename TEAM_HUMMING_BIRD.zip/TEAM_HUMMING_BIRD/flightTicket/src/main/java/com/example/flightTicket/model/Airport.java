package com.example.flightTicket.model;


public class Airport {

private Integer airportId;
private String name;
private String location;
public Integer getAirportId() {
	return airportId;
}
public void setAirportId(Integer airportId) {
	this.airportId = airportId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}

}
