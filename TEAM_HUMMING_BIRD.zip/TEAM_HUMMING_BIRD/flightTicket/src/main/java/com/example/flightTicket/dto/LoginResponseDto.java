package com.example.flightTicket.dto;

import org.springframework.stereotype.Component;

@Component
public class LoginResponseDto {
	public String message;
	 public int status;
	 public int id;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	 
}
