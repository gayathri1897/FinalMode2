package com.company.flightSearch.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.company.flightSearch.dao.AirportRepository;
import com.company.flightSearch.dao.CategoryRepository;
import com.company.flightSearch.dao.FlightRepository;
import com.company.flightSearch.dto.FlightResponseDto;
import com.company.flightSearch.dto.FlightSeatResponseDto;
import com.company.flightSearch.exceptionHandling.AirportNotFoundException;
import com.company.flightSearch.exceptionHandling.FlightNotFoundException;
import com.company.flightSearch.model.Airport;
import com.company.flightSearch.model.Category;
import com.company.flightSearch.model.Flight;
import java.util.Optional;


import ch.qos.logback.classic.Logger;

@Service
public class FlightServiceImpl implements FlightService {
	private final Logger LOGGER = (Logger) LoggerFactory.getLogger(FlightServiceImpl.class);

	@Autowired
	FlightRepository flightRepository;

	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	AirportRepository airportRepository;

	@Autowired
	ModelMapper modelMapper;
	
	@Autowired
	RestTemplate restTemplate;

	List<FlightResponseDto> flightList = new ArrayList<FlightResponseDto>();

	/* Searching for flights with given source, destination and date */
	@Override
	public ResponseEntity<List<FlightResponseDto>> searchFlights(String source, String destination, Date date) {
		flightList.clear();
		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		List<Flight> listOfFlights = (List<Flight>) flightRepository.findFlightBySourceAndDestinationAndDate(source, destination,
				date);
		if (listOfFlights.isEmpty()) {
			throw new FlightNotFoundException("No flights available");
		}
		listOfFlights.forEach(flight->getFlightList(flight));
		return new ResponseEntity<List<FlightResponseDto>>(flightList,HttpStatus.OK);	
	}

	/*setting the FlightResponseDto*/
	public void getFlightList(Flight flight) {
		Optional<Category> optionalCategory = categoryRepository.findById(flight.getFlightId());
		Category category = optionalCategory.get();
		FlightResponseDto flightResponseDto = modelMapper.map(flight, FlightResponseDto.class);
		flightResponseDto.setBusinessCost(category.getBusinessCost());
		flightResponseDto.setBusinessSeats(category.getBusinessSeats());
		flightResponseDto.setEconomyCost(category.getEconomyCost());
		flightResponseDto.setEconomySeats(category.getEconomySeats());
		flightList.add(flightResponseDto);
	}
	
	/* Filter flights by flight name */
	@Override
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByName(String name) {
		List<FlightResponseDto> filteredFlightList = flightList.stream().filter(f -> f.getName().equals(name))
				.collect(Collectors.toList());
		if (filteredFlightList.isEmpty()||flightList.isEmpty()) {
			throw new FlightNotFoundException("No flights with given name available");
		}
		return new ResponseEntity<List<FlightResponseDto>>(filteredFlightList,HttpStatus.OK);
	}

	/* Filter flights by cost */
	@Override
	public ResponseEntity<List<FlightResponseDto>>filterFlightsByCost(double cost) {
		List<FlightResponseDto> filteredFlightList = flightList.stream()
				.filter(f -> f.getBusinessCost() <= cost || f.getEconomyCost() <= cost).collect(Collectors.toList());
		if (filteredFlightList.isEmpty()||flightList.isEmpty()) {
			throw new FlightNotFoundException("No flights available for given cost");
		}
		return new ResponseEntity<List<FlightResponseDto>>(filteredFlightList,HttpStatus.OK);
	}

	/* Check for availibility of seats for given flight */
	@Override
	public ResponseEntity<FlightSeatResponseDto>checkAvailability(int flightId) {
		FlightSeatResponseDto flightSeatResponseDto = new FlightSeatResponseDto();
		Category category;
		java.util.Optional<Category> optionalCategory = categoryRepository.findById(flightId);
		if (!optionalCategory.isPresent()) {
			throw new FlightNotFoundException("No flight with given id available");
		}
		category = optionalCategory.get();
		flightSeatResponseDto.setEconomySeats(category.getEconomySeats());
		flightSeatResponseDto.setBusinessSeats(category.getBusinessSeats());
		return new ResponseEntity<FlightSeatResponseDto>(flightSeatResponseDto,HttpStatus.OK);
	}

	/* Getting name of the airport */
	@Override
	public ResponseEntity<String> getAirportName(String location) {
		Airport airport = airportRepository.findNameByLocation(location);
		if (airport== null)
			throw new AirportNotFoundException("No airport at given location");
		return new ResponseEntity<String>(airport.getName(),HttpStatus.OK);
	}

	/* Updating seats after ticket booking */
	@Override
	public ResponseEntity<Integer> updateSeatsAfterBooking(int flightId, String category, int numberOfTickets) {
		if (category.equalsIgnoreCase("economy")) {
			return new ResponseEntity<Integer>(categoryRepository.deleteEconomySeats(flightId, numberOfTickets),HttpStatus.OK);
		}
		else {
			return new ResponseEntity<Integer>(categoryRepository.deleteBusinessSeats(flightId, numberOfTickets),HttpStatus.OK);
		}
	}
	
	/*updating seats after cancelling the ticket*/
	@Override
	public ResponseEntity<Integer> updateSeatsAfterCancelling(int flightId, String category, int numberOfTickets) {
		if (category.equalsIgnoreCase("economy")) {
			return new ResponseEntity<Integer>(categoryRepository.addEconomySeats(flightId, numberOfTickets),HttpStatus.OK);
		}
		else{
			return new ResponseEntity<Integer>(categoryRepository.addBusinessSeats(flightId, numberOfTickets),HttpStatus.OK);
		}
	}
	
	/*getting the flight details for the given flight Id*/
	@Override
	public ResponseEntity<FlightResponseDto> getFlightDetails(Integer flightId) {
		Optional<Flight>optionalFlight=flightRepository.findById(flightId);
		Optional<Category>optionalCategory=categoryRepository.findById(flightId);
		if(!optionalFlight.isPresent()) {
			throw new FlightNotFoundException("No flight found for the given id");
		}
		Flight flight=optionalFlight.get();
		Category category=optionalCategory.get();
		FlightResponseDto flightResponseDto=modelMapper.map(flight, FlightResponseDto.class);
		flightResponseDto.setBusinessCost(category.getBusinessCost());
		flightResponseDto.setEconomyCost(category.getEconomyCost());
		return new ResponseEntity<FlightResponseDto>(flightResponseDto,HttpStatus.OK);
	}

}
